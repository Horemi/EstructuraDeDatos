#include <iostream>
#include "Empleado.h"
using namespace std;

#define MAX 40

void cargarVector(Empleado v[], int n);
void clasificarBurbuja(Empleado v[], int n);
bool busquedaCodigo(Empleado v[], int n, int clave, int& z);
void listarPlanilla(Empleado v[], int n);
float promedio(Empleado v[], int n);

int main() {
    Empleado vec[MAX];
    int opcion, N = 0, codigo, pos;
    bool bandera;

    do {
        cout << "\n1. Cargar vector\n";
        cout << "2. Clasificar burbuja\n";
        cout << "3. Busqueda por código\n";
        cout << "4. Listar planilla\n";
        cout << "5. Promedio de salarios netos\n";
        cout << "0. Salir\n";
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "¿Cuantos empleados desea cargar? (máx " << MAX << "): ";
            cin >> N;
            if (N > MAX || N < 1) {
                cout << "Cantidad inválida.\n";
                N = 0;
            }
            else {
                cargarVector(vec, N);
            }
            break;
        case 2:
            clasificarBurbuja(vec, N);
            cout << "Vector ordenado por código.\n";
            break;
        case 3:
            cout << "Ingrese el código a buscar: ";
            cin >> codigo;
            bandera = busquedaCodigo(vec, N, codigo, pos);
            if (bandera) {
                cout << "Empleado encontrado:\n";
                vec[pos].mostrar();
            }
            else {
                cout << "No existe el código del empleado.\n";
            }
            break;
        case 4:
            listarPlanilla(vec, N);
            break;
        case 5:
            cout << "Promedio de salarios netos: " << promedio(vec, N) << "\n";
            break;
        case 0:
            cout << "Saliendo...\n";
            break;
        default:
            cout << "Opción no válida.\n";
        }
    } while (opcion != 0);

    return 0;
}
void cargarVector(Empleado v[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "\nEmpleado #" << i + 1 << ":\n";
        v[i].cargar();
    }
}

void clasificarBurbuja(Empleado v[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (v[j].getId() > v[j + 1].getId()) {
                swap(v[j], v[j + 1]);
            }
        }
    }
}

bool busquedaCodigo(Empleado v[], int n, int clave, int& z) {
    for (int i = 0; i < n; i++) {
        if (v[i].getId() == clave) {
            z = i;
            return true;
        }
    }
    return false;
}

void listarPlanilla(Empleado v[], int n) {
    cout << "ID\tNombre\t\tFecha Nac.\tSalario Bruto\tSalario Neto\n";
    cout << "===============================================================\n";
    for (int i = 0; i < n; i++) {
        v[i].mostrar();
    }
}

float promedio(Empleado v[], int n) {
    float suma = 0;
    for (int i = 0; i < n; i++) {
        suma += v[i].getSalarioNeto();
    }
    return (n > 0) ? suma / n : 0;
}
