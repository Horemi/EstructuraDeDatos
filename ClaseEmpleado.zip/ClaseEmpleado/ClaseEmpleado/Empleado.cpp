#include "Empleado.h"
#include <iostream>
using namespace std;

// Constructor por defecto: asigna cada elemento individualmente
Empleado::Empleado() {
    id = 0;
    nombre = "";
    fechanac = "";
    sb = 0.0;
    sn = 0.0;
}

// Constructor parameterizado: asigna cada miembro expl�citamente y calcula sn
Empleado::Empleado(int id, string nombre, string fechanac, float sb) {
    this->id = id;
    this->nombre = nombre;
    this->fechanac = fechanac;
    this->sb = sb;
    // Calcular el salario neto, asumiendo un descuento del 12%
    this->sn = sb - (sb * 0.12f);
}

void Empleado::cargar() {
    cout << "ID: ";
    cin >> id;
    cin.ignore();
    cout << "Nombre: ";
    getline(cin, nombre);
    cout << "Fecha de nacimiento: ";
    getline(cin, fechanac);
    cout << "Salario bruto: ";
    cin >> sb;
    calcularSalarioNeto();
}

void Empleado::calcularSalarioNeto() {
    sn = sb - (sb * 0.12f); // 12% de descuento
}

void Empleado::mostrar() {
    cout << id << "\t" << nombre << "\t" << fechanac << "\t"
        << sb << "\t" << sn << "\n";
}

int Empleado::getId() { 
    return id; 
}
float Empleado::getSalarioBruto() {
    return sb; 
}
float Empleado::getSalarioNeto() {
    return sn; 
}
string Empleado::getNombre() {
    return nombre; 
}
string Empleado::getFechaNacimiento() {
    return fechanac; 
}
