#pragma once
#include <string>

using namespace std;

class Empleado {
private:
    int id;
    string nombre;
    string fechanac;
    float sb;
    float sn;

public:
    // Constructor por defecto (sin par�metros)
    Empleado();

    // Constructor parameterizado: inicializa cada miembro con el valor recibido.
    // Se calcula sn a partir de sb (por ejemplo, con un descuento del 12%).
    Empleado(int id, string nombre, string fechanac, float sb);

    void cargar();
    void calcularSalarioNeto();
    void mostrar() ;

    int getId() ;
    float getSalarioBruto() ;
    float getSalarioNeto() ;
    string getNombre() ;
    string getFechaNacimiento() ;
};